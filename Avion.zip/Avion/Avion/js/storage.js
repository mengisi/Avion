/**
 * Assurer la sauvegarde des données
 * Notamment d'une page à l'autre
 */

/**
 *
 */
function save_data() {

}

/**
 *
 */
function restore_data() {

}
