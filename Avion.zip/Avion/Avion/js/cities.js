
var cities_tb = [
    {name:'Tokyo',			        country:'Japan',		                    pop: 34100000,       value:2500},
    {name:'Mexico City',			country:'Mexico',		                    pop: 22650000,       value:2200},
    {name:'Seoul',			        country:'South Korea',		                pop: 22250000,       value:2100},
    {name:'New York',			    country:'United States',	                pop: 21850000,       value:1800},
    {name:'Sao Paulo',			    country:'Brazil',		                    pop: 20200000,       value:1900},
    {name:'Mumbai',			        country:'India',		                    pop: 19700000,       value:3000},
    {name:'Dehli',			        country:'India',		                    pop: 19500000,       value:2700},
    {name:'Los Angeles',			country:'United States',		            pop: 17950000,       value:2650},
    {name:'Shanghai',			    country:'China',		                    pop: 17900000,       value:2300},
    {name:'Jakarta',			    country:'Indonesia',		                pop: 17150000,       value:1400},
    {name:'Osaka',			        country:'Japan',		                    pop: 16800000,       value:1700},
    {name:'Kolkata',			    country:'India',		                    pop: 15550000,       value:2600},
    {name:'Cairo',			        country:'Egypt',		                    pop: 15450000,       value:2400},
    {name:'Manila',			        country:'Philippines',		                pop: 14850000,       value:1500},
    {name:'Karachi',			    country:'Pakistan',		                    pop: 14100000,       value:1000},
    {name:'Moscow',			        country:'Russia',		                    pop: 13750000,       value:3200},
    {name:'Buenos Aires',			country:'Argentina',	                    pop: 13400000,       value:1200},
    {name:'Dhaka',			        country:'Bangladesh',		                pop: 13100000,       value:1000},
    {name:'Rio de Janeiro',			country:'Brazil',	                        pop: 12100000,       value:2500},
    {name:'Beijing',			    country:'China',		                    pop: 11950000,       value:2000},
    {name:'London',			        country:'United Kingdom',	                pop: 11950000,       value:1800},
    {name:'Tehran',			        country:'Iran',		                        pop: 11800000,       value:1100},
    {name:'Istanbul',			    country:'Turkey',		                    pop: 11400000,       value:1400},
    {name:'Lagos',			        country:'Nigeria',		                    pop: 11000000,       value:1300},
    {name:'Shenzhen',			    country:'China',		                    pop: 10450000,       value:1250},
    {name:'Paris',			        country:'France',		                    pop: 9900000,        value:2000},
    {name:'Chicago',			    country:'United States',	                pop: 9750000,        value:1950},
    {name:'Guangzhou',			    country:'China (Canton)',		            pop: 9400000,        value:2050},
    {name:'Chongqing',			    country:'China (Chungking)',	            pop: 9200000,        value:1489},
    {name:'Wuhan',			        country:'China',		                    pop: 8950000,        value:1450},
    {name:'Lima',			        country:'Peru',		                        pop: 8500000,        value: 800},
    {name:'Bogota',			        country:'Colombia',		                    pop: 8250000,        value: 950},
    {name:'Washington-Baltimore',	country:'United States',		            pop: 8100000,        value:1720},
    {name:'Nagoya',			        country:'Japan',		                    pop: 8050000,        value:1540}
];









